package com.example.connectfour;

public class ConnectFourGame {
    // 2. Add member variable board as a two-dimensional integer array, size 7 rows and 6 columns
    private final int[][] board;

    // 3. Define a custom constructor that instantiates the board array
    public ConnectFourGame() {
        board = new int[7][6];
    }

    // 4. Define method newGame
    public void newGame() {

        // d. Iterate through the 2-d array board to initialize each element to the value zero (0)
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 6; j++) {
                board[i][j] = 0;
            }
        }
    }

    // 5. Define method getState
    public String getState() {
        // a. Access level modifier: public
        // b. Return type: String
        // c. Parameter list: empty

        // d. Instantiate an instance of class StringBuilder
        StringBuilder stateBuilder = new StringBuilder();

        // e. Iterate through the 2-d array board to append each element to the StringBuilder object
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 6; j++) {
                stateBuilder.append(board[i][j]);
            }
        }

        // f. Return the StringBuilder object appending method toString()
        return stateBuilder.toString();
    }
}
