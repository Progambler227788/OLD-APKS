package com.example.connectfour;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.gridlayout.widget.GridLayout;

public class BoardFragment extends Fragment {
    public static final String GAME_STATE = "gameState";
    private ConnectFourGame mGame;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_board, container, false);

        GridLayout mGrid = view.findViewById(R.id.grid_layout);
        mGame = new ConnectFourGame();

        for (int i = 0; i < mGrid.getChildCount(); i++) {
            if (mGrid.getChildAt(i) instanceof Button) {
                Button button = (Button) mGrid.getChildAt(i);

                button.setOnClickListener(this::onButtonClick);
            }
        }

        return view;
    }

    public void onButtonClick(View view) {
        // Handle button click here
        Log.i("Clicked","Hi");
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        // Save the game state
        outState.putString(GAME_STATE, mGame.getState());
    }
}
