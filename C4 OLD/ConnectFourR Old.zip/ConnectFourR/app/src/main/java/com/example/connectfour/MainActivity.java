package com.example.connectfour;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {

    private ActivityResultLauncher<Intent> launcher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the ActivityResultLauncher
        launcher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        // Obtain the selected mode from the intent result
                        Intent data = result.getData();
                        if (data != null) {
                            String selectedMode = data.getStringExtra("mode_type");
                            if (selectedMode != null) {
                                // Displaying a Toast with the selected mode
                                Toast.makeText(MainActivity.this, selectedMode + " Mode", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });

        Button connectFourButton = findViewById(R.id.c4);
        connectFourButton.setOnClickListener(view -> {
            // Go to Board Activity
            Intent intent = new Intent(MainActivity.this, Board.class);
            startActivity(intent);
        });

        Button optionsButton = findViewById(R.id.options);
        optionsButton.setOnClickListener(view -> {
            // Go to game options activity
            Intent intent = new Intent(MainActivity.this, GameOptions.class);
            launcher.launch(intent); // Use the ActivityResultLauncher to start the activity
        });
    }

}

