package com.example.connectfour;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class Board extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_board); // Initialize the content of Board

    }
}