package com.example.connectfour;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class GameOptions extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_options);
        RadioButton easyRadioButton = findViewById(R.id.easy);
        RadioButton mediumRadioButton = findViewById(R.id.medium);
        RadioButton hardRadioButton = findViewById(R.id.hard);
      // calling triggerGameMode() method if any radio button get clicked by user
        easyRadioButton.setOnClickListener(view -> triggerGameMode());

        mediumRadioButton.setOnClickListener(view -> triggerGameMode());

        hardRadioButton.setOnClickListener(view -> triggerGameMode());
    }
    private void triggerGameMode() {
        RadioGroup radioOptions = findViewById(R.id.radioOptions); // id of radio group having three radio buttons
        int mode = radioOptions.getCheckedRadioButtonId();
        if (mode != -1) { // checking for checked radio button exists or not
            RadioButton selectedMode = findViewById(mode);
            String selectedGameMode = selectedMode.getText().toString(); // easy,medium,hard

            Intent resultIntent = new Intent(); // making Intent class object with new (heap) memory
            resultIntent.putExtra("mode_type", selectedGameMode); // add data about mode in Intent

            setResult(RESULT_OK, resultIntent);
            finish(); // closing
        }
    }

}
