package com.example.matheducation.model


data class viewscoremodel(val score: String, val date: String,val id:String)
