package com.example.matheducation

import DatabaseHelper
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.matheducation.databinding.ActivityStudentmainscreenBinding
import com.example.matheducation.permission.geopermission

class studentmainscreen : AppCompatActivity() {

    private lateinit var binding : ActivityStudentmainscreenBinding

    companion object{
        lateinit var dbHelper :DatabaseHelper;
        lateinit var sharedPreferences : SharedPreferences
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStudentmainscreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
        geopermission.requestPermissions(this);
        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        dbHelper = DatabaseHelper(this,  sharedPreferences)

//        val name = intent.getStringExtra("user").toString()
//        val id = intent.getStringExtra("id").toString()

        binding.test.setOnClickListener {
            val intent = Intent(this, testing::class.java)
//            intent.putExtra("id", id)
//            intent.putExtra("name", name)
            startActivity(intent)
            finish()
        }

        binding.score.setOnClickListener {
            val intent = Intent(this, viewscore::class.java)
//            intent.putExtra("id", id)
            startActivity(intent)
        }

    }
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String?>,
        results: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (!geopermission.hasGeoPermissions(this)) {
            // Use toast instead of snackbar here since the activity will exit.
            if (!geopermission.shouldShowRequestPermissionRationale(this)) {
                // Permission denied with checking "Do not ask again".
                geopermission.launchPermissionSettings(this)
            }
            finish()
        }
    }
}